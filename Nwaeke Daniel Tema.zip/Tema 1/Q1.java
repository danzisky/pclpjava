public class Q1 {
    
}
